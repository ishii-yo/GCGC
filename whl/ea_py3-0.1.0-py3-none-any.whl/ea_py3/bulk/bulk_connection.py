# -*- coding: utf-8 -*-
from ..core import dw_connection as dw_con
from ..core import py_signal as ps
from ..core import functions as func
from .. import dw_exception as ex
from .. import const
from enum import IntEnum
__author__ = 'ishii.y'


class BulkMode(IntEnum):
    AUTO = 1
    NEW = 2
    APPEND = 3
    UPDATE = 4


class NullCharMode(IntEnum):
    ASIS = 1
    ERROR = 2


def connect(server, port, user, pwd, db):
    """
    DBにコネクトしたBulkImporterを返す。
    :param server:
    :param port:
    :param user:
    :param pwd:
    :param db:
    :return:
    """
    con = BulkImporter()
    con.login_and_connect(server, port, user, pwd, db)
    return con


class BulkImporter(object):

    def __init__(self):
        self.con = dw_con.DwConnection()
        self.h_db = 0
        self.values = []  # 2次元のiterativeなオブジェクトならlist以外も可。
        self.h_bulk = 0
        self.null_char_mode = NullCharMode.ASIS

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __init_param(self):
        """
        パラメーターの初期化
        :return:
        """
        self.h_db = 0
        self.values = []
        self.h_bulk = 0
        self.null_char_mode = NullCharMode.ASIS

    def login_and_connect(self, server, port, user, pwd, db):
        self.con.login(server, port, user, pwd, ps.Signal.pylsql)
        try:
            self.__connect(db)
        except Exception as e:
            self.con.logout()
            raise e

    def __connect(self, db):
        """
        db connect。connectしている場合はcloseしてからconnect。
        :param:db
        :return:
        """
        self.__close_db()
        self.h_db = self.con.connect(db)

    def close(self):
        """
        DBのdisconnect及びログアウト。
        :return:
        """
        try:
            self.__close_db()
        finally:
            self.con.logout()

    def __close_db(self):
        """
        db,bulkクローズ。connectしていない場合は何もしない。
        パラメーター類を初期化。
        :return:
        """
        try:
            self.bulk_close()
        finally:
            self.con.close_db(self.h_db)
            self.__init_param()

    def bulk_begin(self, table, mode=BulkMode.AUTO, column=''):
        self.bulk_close()

        py_str = ""
        if len(column) == 0:
            py_str += "bulk_handle=DWPyXport.BulkBegin(login_handle,%d,0,'%s',%d)\n" \
                  % (self.h_db, func.convert_quotes(table), mode)
        else:
            # update load
            py_str += "bulk_handle=DWPyXport.BulkBegin(login_handle,%d,0,'%s',%d, '%s')\n" \
                  % (self.h_db, func.convert_quotes(table), BulkMode.UPDATE, func.convert_quotes(column))

        py_str += "if DWPyXport.error>=0 and bulk_handle!=0:\n"
        py_str += "  s_bulk_handle=str(bulk_handle)\n"
        self.con.python.run_string(py_str)
        ret, msg = self.con.get_error_code('DWPyXport')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        str_h = self.con.python.get_value_string("s_bulk_handle")
        self.h_bulk = int(str_h)

    def bulk_close(self):
        if self.h_bulk == 0:
            return
        py_str = ""
        py_str += "DWPyXport.BulkClose(login_handle,%d)\n" % self.h_bulk
        self.con.python.run_string(py_str)
        ret, msg = self.con.get_error_code('DWPyXport')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        self.h_bulk = 0

    def bulk_insert(self):
        if len(self.values) == 0:
            return
        values_list = []
        col_dlm = '\x01'
        for row in self.values:
            values_list.append(self.row_str(row, col_dlm, self.null_char_mode, self.con.get_locale()))
        self.clear_values()
        py_str = ""
        py_str += "DWPyXport.BulkInsert(login_handle,%d,%s)\n" % (self.h_bulk, str(values_list))
        self.con.python.run_string(py_str)
        ret, msg = self.con.get_error_code('DWPyXport')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)

    @classmethod
    def row_str(cls, row, dlm, null_car_mode, locale):
        """
        1行分のデータ文字列生成。
        :param row:
        :param dlm:
        :param null_car_mode:
        :param locale:
        :return:
        """
        converted = [cls.convert_quote(x, null_car_mode, locale) for x in row]
        return dlm.join(converted)

    @classmethod
    def convert_quote(cls, value, null_car_mode, locale):
        """
        1セル分の文字列を変換
        :param value:
        :param null_car_mode:
        :param locale:
        :return:
        """
        if value is None:
            return '\x19'
        if isinstance(value, str) is False:
            # 文字列以外
            return value
        ret = ""
        for x in value:
            if x == "\x00":
                if null_car_mode == NullCharMode.ASIS:
                    ret += x
                else:
                    raise ex.create(const.DWAPI_DBM_ERR_ILLEGAL_CHARACTER, locale)
            elif x == '\x01' or x == '\x02':
                raise ex.create(const.DWAPI_DBM_ERR_ILLEGAL_CHARACTER, locale)
            else:
                ret += x
        return ret

    def bulk_commit(self):
        py_str = ""
        py_str += "DWPyXport.BulkCommit(login_handle,%d)\n" % self.h_bulk
        self.con.python.run_string(py_str)
        ret, msg = self.con.get_error_code('DWPyXport')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        # BulkCommit内で開放しているので0にする。
        self.h_bulk = 0

    def add_row(self, row):
        """
        1行分のデータを追加
        :param row:
        :return:
        """
        self.values.append(row)

    def add_rows(self, rows):
        """
        複数行のデータを追加
        :param rows:
        :return:
        """
        self.values += rows

    def clear_values(self):
        self.values = []


