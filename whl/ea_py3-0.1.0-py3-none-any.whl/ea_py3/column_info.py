# -*- coding: utf-8 -*-
from enum import IntEnum
__author__ = 'ishii.y'


def create_from_py_result(info_str):
    """
    pyrunstringの結果から生成する。
    :param info_str:
    :return:
    """
    return ColumnInfo(info_str)


class ColumnInfo:
    def __init__(self, info_str):
        info_list = info_str.split('\x01')
        self.id = int(info_list[0])
        self.type = ColumnType(int(info_list[1]))
        self.null = int(info_list[2])
        self.unique = int(info_list[3])
        self.precision = int(info_list[4])
        self.scale = int(info_list[5])
        self.name = info_list[6]
        self.comment = info_list[7]
        self.table = info_list[8]
        self.display = info_list[9]
        self.display_size = int(info_list[10])
        self.internal_size = int(info_list[11])
        self.default = ''
        if len(info_list) >= 13:
            self.default = info_list[12]

    def __str__(self):
        return 'id=%d,type=%s,null=%d,unique=%d,precision=%d,scale=%d,name=%s,comment=%s,table=%s,display=%s,' \
               'display_size=%d,internal_size=%d,default=%s' % (self.id, self.type, self.null, self.unique,
                                                                self.precision, self.scale, self.name, self.comment,
                                                                self.table, self.display, self.display_size,
                                                                self.internal_size, self.default)


class ColumnType(IntEnum):
    VARCHAR = 0
    INTEGER = 1
    REAL = 2
    DATE = 3
    TIME = 4
    TIMESTAMP = 5
    OBJECT = 6
    NUMERIC = 7
    NULL = 10
    INTERVAL = 12
