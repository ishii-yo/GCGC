# -*- coding: utf-8 -*-
from . import decode_stream as dec
from . import encode_stream as enc
from . import dw_socket as sock
from . import py_signal as ps
from .. import dw_exception as ex
__author__ = 'ishii.y'


def connect(ip_address, port, locale, encode):
        con = Connection(encode, locale)
        con.connect(ip_address, port)
        return con


class Connection:
    def __init__(self, encode, locale):
        self.encode = encode
        self.locale = locale
        self.ip_address = ""
        self.port = 0
        self.h_session = 0
        self.multilingual = False
        self.socket = sock.dw_socket()
        self.ostream = enc.EncodeStream()
        self.istream = dec.DecodeStream()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

    def connect(self, ip_address, port):
        """
        :param ip_address:
        :param port:
        :return:
        """
        self.socket.connect(ip_address, port)
        self.ostream.reset()
        self.ostream.write_4bytes(self.h_session)
        self.ostream.write_4bytes(ps.Signal.connect)

        self.send()
        self.recv()

        ret = self.istream.read_4bytes()
        if ret >= 0x80000000:
            raise ex.create(ret, self.locale)
        self.h_session = self.istream.read_4bytes()
        self.multilingual = (ret == 1)

    def disconnect(self):
        self.ostream.reset()
        try:
            self.ostream.write_4bytes(self.h_session)
            self.ostream.write_4bytes(ps.Signal.disconnect)
            self.send()
        finally:
            self.socket.disconnect()
            self.h_session = 0

    def read_bytes(self):
        return self.istream.read_bytes()

    def read_4bytes(self):
        return self.istream.read_4bytes()

    def read_8bytes(self):
        return self.istream.read_8bytes()

    def read_string(self):
        """
        文字列の読み込み
        :return:
        """
        return self.istream.read_string(self.encode)

    def write_bytes(self, byte_array):
        self.ostream.write_bytes(byte_array)

    def write_4bytes(self, value):
        self.ostream.write_4bytes(value)

    def write_string(self, value):
        """
        文字列の書き込み
        :param value:
        :return:
        """
        self.ostream.write_string(value, self.encode)

    def send(self):
        self.socket.send(self.ostream.to_byte_array())
        self.ostream.reset()

    def recv(self):
        self.istream.set(self.socket.recv())

    def get_local_address(self):
        return self.socket.get_local_address()

    def is_multilingual(self):
        return self.multilingual

    def get_session_handle(self):
        return self.h_session

    def get_locale(self):
        return self.locale
