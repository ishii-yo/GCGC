# -*- coding: utf-8 -*-
__author__ = 'ishii.y'


class DecodeStream(object):
    """"
    受信用ストリームクラス
    """
    def __init__(self):
        self.byte_array = bytearray([])
        self.bytes_len = 0
        self.pos = 0
        self.locale = 0

    def set(self, byte_array):
        byte0 = byte_array[36]
        byte1 = byte_array[37]
        byte2 = byte_array[38]
        byte3 = byte_array[39]
        byte3 ^= byte0
        byte2 ^= byte3
        byte1 ^= byte2
        byte0 ^= byte1

        key = byte0
        key |= byte1 << 8
        key |= byte2 << 16
        key |= byte3 << 24

        self.bytes_len = len(byte_array) - 40
        self.pos = 0
        self.byte_array = bytearray([])

        mask = []
        for i in range(0, min(25, self.bytes_len)):
            mask.append((key >> i) & 0xff)
            value = byte_array[40 + i] ^ mask[i]
            self.byte_array.append(value)

        for i in range(25, self.bytes_len):
            value = byte_array[40 + i] ^ mask[i % 25]
            self.byte_array.append(value)

    def read_4bytes(self):
        value_len = self.__get_msg_len()
        if value_len != 4:
            # FIXME:適切な例外
            raise IndexError("length not 4 bytes.(%d)" % value_len)
        value = self.__read()
        value |= self.__read() << 8
        value |= self.__read() << 16
        value |= self.__read() << 24
        return value

    def read_8bytes(self):
        value_len = self.__get_msg_len()
        if value_len != 8:
            # FIXME:適切な例外
            raise IndexError("length not 8 bytes.(%d)" % value_len)
        value = self.__read()
        value |= self.__read() << 8
        value |= self.__read() << 16
        value |= self.__read() << 24
        value |= self.__read() << 32
        value |= self.__read() << 40
        value |= self.__read() << 48
        value |= self.__read() << 56
        return value

    def read_bytes(self):
        """
        TODO:効率化できる。
        :return:
        """
        value_len = self.__get_msg_len()
        ret = bytearray([])
        for _ in range(value_len):
            ret.append(self.__read())
        return ret

    def read_string(self, encode):
        """
        UNICODE文字列に変換して返す。
        :param encode:
        :return:
        """
        byte_array = self.read_bytes()
        # UNICODE文字列に変換
        ret = byte_array.decode(encode)
        return ret[:len(ret) - 1]

    def __get_msg_len(self):
        value_len = self.__read()
        value_len |= self.__read() << 8
        value_len |= self.__read() << 16
        value_len |= self.__read() << 24
        return value_len

    def __read(self):
        if self.pos >= self.bytes_len:
            raise IndexError("out of index.pos=[%d],bytes_len=[%d]" % (self.pos, self.bytes_len))
        ret = self.byte_array[self.pos]
        self.pos += 1
        return ret
