# -*- coding: utf-8 -*-
from .. import dw_exception as ex
from . import login_handle as lh
from .. import const
from .. import database_info
from .. import table_info
from ..core import functions as func

__author__ = 'ishii.y'


class DwConnection(object):
    """
    各Connectionの基本クラス。
    直接生成する事は想定していない。
    """
    default_version = const.SERVER_VERSION_50
    default_locale = const.LOCALE_JPN

    def __init__(self):
        self.login_handle = None
        self.signal = 0
        self.python = None
        self.is_login = False
        self.is_python = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.logout()

    @classmethod
    def get_default_version(cls):
        return cls.default_version

    @classmethod
    def get_default_locale(cls):
        return cls.default_locale

    def get_server_version(self):
        return self.login_handle.get_server_version()

    def get_locale(self):
        return self.login_handle.get_locale()

    def login(self, server, port, user, pwd, signal):
        """
        ログイン及びPython Interpreterの生成
        :param server:
        :param port:
        :param user:
        :param pwd:
        :param signal:
        :return:
        """
        self.login_handle = lh.create_and_login(server, port, user, pwd, '', '',
                                                self.default_version, self.default_locale, None)
        try:
            self.python = self.login_handle.create_interpreter(signal)
            self.python.run_string('database_handle=0\n')
            self.is_login = True
            self.is_python = True
        except Exception as e:
            self.login_handle.logout()
            raise e

    def logout(self):
        self.python.disconnect()
        self.login_handle.logout()
        self.is_login = False
        self.is_python = False

    def connect(self, db):
        """
        dbへの接続を実行してハンドルを返す。
        :param:db
        :return:
        """
        py_str = "handle=DWPyDBM.CONNECT(login_handle,'%s')\n" \
                 "if DWPyDBM.error>=0 and handle!=0:\n" \
                 "  s_database_handle=str(handle)\n" % func.convert_quotes(db)
        self.python.run_string(py_str)
        ret, msg = self.get_error_code('DWPyDBM')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        str_h = self.python.get_value_string("s_database_handle")
        return int(str_h)

    def close_db(self, h_db):
        """
        dbクローズ。connectしていない場合は何もしない。
        :return:
        """
        if h_db == 0:
            return
        py_str = "DWPyDBM.CLOSE(%d)\n" % h_db
        self.python.run_string(py_str)
        ret, msg = self.get_error_code('DWPyDBM')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)

    def get_error_code(self, module):
        """
        エラーコードを取得
        FIXME:とりあえずここに記述するが、適切な場所に移したい。
        :param module:
        :return:
        """
        err_mgs_jpn_utf8 = "error_msg_jpn_utf8"
        err_mgs_eng_utf8 = "error_msg_eng_utf8"
        err_mgs_chn_utf8 = "error_msg_chn_utf8"

        code = ""
        code += "code=" + module + ".error\n"
        if self.login_handle.is_multilingual():
            if self.login_handle.get_locale() == const.LOCALE_JPN:
                code += "msg=" + module + "." + err_mgs_jpn_utf8 + "\n"
            elif self.login_handle.get_locale() == const.LOCALE_ENG:
                code += "msg=" + module + "." + err_mgs_eng_utf8 + "\n"
            elif self.login_handle.get_locale() == const.LOCALE_CHN:
                code += "msg=" + module + "." + err_mgs_chn_utf8 + "\n"
        else:
            # マルチリンガル(utf-8)以外は対応しない。
            raise ex.create(const.DWAPI_NO_SUPPORT, self.login_handle.get_locale())

        self.python.run_string(code)
        err = self.python.get_value_int("code")
        msg = ''
        if err > 0x80000000:
            if self.login_handle.is_multilingual():
                msg = self.python.get_value_string('msg')
        return err, msg

    def get_database_list(self):
        """
        DBリストを取得
        :return:
        """
        db_name_list = self.__get_db_name_list()
        db_list = []
        for db_name in db_name_list:
            try:
                db = self.__get_db_info(db_name)
            except ex.DwException:
                # 例外発生時は名前だけの構造を返す
                db = database_info.default_db_info(db_name)
            db_list.append(db)
        return db_list

    def get_table_list(self, db_name):
        """
        テーブルリストを取得
        :param db_name:
        :return:
        """
        py_str = "result=DWPyUser.GetTableList(login_handle,'%s')\n" % func.convert_quotes(db_name)
        self.python.run_string(py_str)
        ret, msg = self.get_error_code('DWPyUser')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        py_str = "ltype=[]\n" \
                 "lname=[]\n" \
                 "lcmt=[]\n" \
                 "lcol=[]\n" \
                 "lsel=[]\n" \
                 "lcon=[]\n" \
                 "lmod=[]\n" \
                 "lmod_user=[]\n" \
                 "ldef_mod=[]\n" \
                 "ldef_mod_user=[]\n" \
                 "lbrok=[]\n" \
                 "lpart=[]\n" \
                 "lmstat=[]\n" \
                 "def_mod_list=''\n" \
                 "def_mod_user_list=''\n" \
                 "brok_list=''\n" \
                 "part_list=''\n" \
                 "mstat_list=''\n" \
                 "for item in result:\n" \
                 "  ltype.append(str(item[6]))\n" \
                 "  ltype.append('\\x01')\n" \
                 "  lname.append(item[3])\n" \
                 "  lname.append('\\x01')\n" \
                 "  lcmt.append(' ')\n" \
                 "  lcmt.append(item[5])\n" \
                 "  lcmt.append('\\x01')\n" \
                 "  lcol.append(' ')\n" \
                 "  lcol.append(item[8])\n" \
                 "  lcol.append('\\x01')\n" \
                 "  lsel.append(' ')\n" \
                 "  lsel.append(item[9])\n" \
                 "  lsel.append('\\x01')\n" \
                 "  lcon.append(' ')\n" \
                 "  lcon.append(item[10])\n" \
                 "  lcon.append('\\x01')\n" \
                 "  lmod.append(' ')\n" \
                 "  lmod.append(item[4])\n" \
                 "  lmod.append('\\x01')\n" \
                 "  lmod_user.append(' ')\n" \
                 "  lmod_user.append(item[7])\n" \
                 "  lmod_user.append('\\x01')\n"
        if self.get_server_version() >= const.SERVER_VERSION_30SP2:
            py_str += "  ldef_mod.append(' ')\n"
            py_str += "  ldef_mod.append(item[12])\n"
            py_str += "  ldef_mod.append('\\x01')\n"
            py_str += "  ldef_mod_user.append(' ')\n"
            py_str += "  ldef_mod_user.append(item[13])\n"
            py_str += "  ldef_mod_user.append('\\x01')\n"
            py_str += "  lbrok.append(' ')\n"
            py_str += "  lbrok.append(str(item[2]))\n"
            py_str += "  lbrok.append('\\x01')\n"
            py_str += "  lpart.append(' ')\n"
            py_str += "  lpart.append(str(item[14]))\n"
            py_str += "  lpart.append('\\x01')\n"
            if self.get_server_version() >= const.SERVER_VERSION_50:
                py_str += "  lmstat.append(' ')\n"
                py_str += "  lmstat.append(str(item[16]))\n"
                py_str += "  lmstat.append('\\x01')\n"
            else:
                py_str += "  mstat_list=mstat_list+' '+str(0)+'\\x01'\n"
            py_str += "def_mod_list=''.join(ldef_mod)\n"
            py_str += "def_mod_user_list=''.join(ldef_mod_user)\n"
            py_str += "brok_list=''.join(lbrok)\n"
            py_str += "part_list=''.join(lpart)\n"
            if self.get_server_version() >= const.SERVER_VERSION_50:
                py_str += "mstat_list=''.join(lmstat)\n"
        elif self.get_server_version() >= const.SERVER_VERSION_30:
            py_str += "  def_mod_list=def_mod_list+' '+item[12]+'\\x01'\n"
            py_str += "  def_mod_user_list=def_mod_user_list+' '+item[13]+'\\x01'\n"
            py_str += "  brok_list=brok_list+' '+str(0)+'\\x01'\n"
            py_str += "  part_list=part_list+' '+str(0)+'\\x01'\n"
            py_str += "  mstat_list=mstat_list+' '+str(0)+'\\x01'\n"
        else:
            py_str += "  def_mod_list=def_mod_list+' '+'\\x01'\n"
            py_str += "  def_mod_user_list=def_mod_user_list+' '+'\\x01'\n"
            py_str += "  brok_list=brok_list+' '+str(0)+'\\x01'\n"
            py_str += "  part_list=part_list+' '+str(0)+'\\x01'\n"
            py_str += "  mstat_list=mstat_list+' '+str(0)+'\\x01'\n"

        py_str += "type_list=''.join(ltype)\n"
        py_str += "name_list=''.join(lname)\n"
        py_str += "cmt_list=''.join(lcmt)\n"
        py_str += "col_list=''.join(lcol)\n"
        py_str += "sel_list=''.join(lsel)\n"
        py_str += "con_list=''.join(lcon)\n"
        py_str += "mod_list=''.join(lmod)\n"
        py_str += "mod_user_list=''.join(lmod_user)\n"
        self.python.run_string(py_str)

        type_str = self.python.get_value_string("type_list")
        name_str = self.python.get_value_string("name_list")
        cmt_str = self.python.get_value_string("cmt_list")
        col_str = self.python.get_value_string("col_list")
        sel_str = self.python.get_value_string("sel_list")
        con_str = self.python.get_value_string("con_list")
        mod_str = self.python.get_value_string("mod_list")
        mod_user_str = self.python.get_value_string("mod_user_list")
        def_mod_str = self.python.get_value_string("def_mod_list")
        def_mod_user_str = self.python.get_value_string("def_mod_user_list")
        brok_str = self.python.get_value_string("brok_list")
        part_str = self.python.get_value_string("part_list")
        mstat_str = self.python.get_value_string("mstat_list")
        type_list = type_str.split('\x01')
        name_list = name_str.split('\x01')
        cmt_list = cmt_str.split('\x01')
        col_list = col_str.split('\x01')
        sel_list = sel_str.split('\x01')
        con_list = con_str.split('\x01')
        mod_list = mod_str.split('\x01')
        mod_user_list = mod_user_str.split('\x01')
        def_mod_list = def_mod_str.split('\x01')
        def_mod_user_list = def_mod_user_str.split('\x01')
        brok_list = brok_str.split('\x01')
        part_list = part_str.split('\x01')
        mstat_list = mstat_str.split('\x01')
        tb_num = len(type_list) - 1
        tables = []
        for i in range(tb_num):
            tab = {
                'type': int(type_list[i]),
                'name': name_list[i],
                'comment': cmt_list[i][1:],
                'column': col_list[i][1:],
                'select': sel_list[i][1:],
                'connect': con_list[i][1:],
                'modify_date': mod_list[i][1:],
                'modify_user': mod_user_list[i][1:],
                'define_date': def_mod_list[i][1:],
                'define_user': def_mod_user_list[i][1:],
                'broken': int(brok_list[i]),
                'partition': int(part_list[i]),
                'inmemory': int(mstat_list[i]),
            }
            tables.append(table_info.create(tab))
        return tables

    def __get_db_name_list(self):
        """
        db名のリストを取得
        :return:
        """
        py_str = "result=DWPyUser.GetPathList(login_handle,1)\n"
        self.python.run_string(py_str)
        ret, msg = self.get_error_code('DWPyUser')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)

        py_str = "name_list=''\n" \
                 "for item in result:\n" \
                 "  name_list=name_list+item[1]+'\\n'\n"
        self.python.run_string(py_str)
        db_names_str = self.python.get_value_string("name_list")
        db_name_list = db_names_str.split('\n')
        db_name_list.pop()
        return db_name_list

    def __get_db_info(self, db_name):
        """
        db名からdb情報を取得する
        :param db_name_list:
        :return:
        """
        py_str = "result=DWPyUser.GetDBInfo(login_handle,'%s')\n" % func.convert_quotes(db_name)
        self.python.run_string(py_str)
        ret, msg = self.get_error_code('DWPyUser')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)

        null_type = "null_type=result[9]\n"
        if self.get_server_version() < const.SERVER_VERSION_30:
            null_type = "null_type=1\n"

        py_str = "name=result[0]\n" \
                 "path=result[1]\n" \
                 "enabled=result[2]\n" \
                 "crsm=result[3]\n" \
                 "crsp=result[4]\n" \
                 "crxm=result[5]\n" \
                 "crxp=result[6]\n" \
                 "rs=result[7]\n" \
                 "exist=result[8]\n" \
                 "%s" % null_type
        self.python.run_string(py_str)
        db_info = {'name': self.python.get_value_string("name"),
                   'path': self.python.get_value_string("path"),
                   'rs': self.python.get_value_int("rs"),
                   'null': self.python.get_value_int("null_type"),
                   'enabled': self.python.get_value_int("enabled"),
                   'dat_mem_size': self.python.get_value_int("crsm"),
                   'dat_page_size': self.python.get_value_int("crsp"),
                   'crx_mem_size': self.python.get_value_int("crxm"),
                   'crx_page_size': self.python.get_value_int("crxp"),
                   'exists': True
                   }
        return database_info.create(db_info)


