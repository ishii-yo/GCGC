# -*- coding: utf-8 -*-
import socket

__author__ = 'ishii.y'


def dw_socket():
    """
    ソケットを返す。
    :param host:
    :param port:
    :return:
    """
    return DWSocket()


class DWSocket(object):
    def __init__(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.is_connect = False

    def __del__(self):
        if self.is_connect:
            self.disconnect()

    def connect(self, host, port):
        self.socket.connect((host, port))
        self.is_connect = True

    def disconnect(self):
        # self.socket.shutdown(socket.SHUT_RDWR)
        self.socket.close()
        self.is_connect = False

    def recv(self):
        chunks = b''
        bytes_recd = 0

        len_str = self.socket.recv(4)
        msg_len = self.__get_msg_len(len_str)
        while bytes_recd < msg_len:
            chunk = self.socket.recv(min(msg_len - bytes_recd, 4096))
            if chunk == '':
                raise RuntimeError("socket connection broken")
            chunks += chunk
            bytes_recd += len(chunk)
        return chunks

    def send(self, send_str):
        total_sent = 0
        msg = self.__create_len_array(send_str) + send_str
        msg_len = len(msg)
        while total_sent < msg_len:
            sent = self.socket.send(msg[total_sent:])
            if sent == 0:
                raise RuntimeError("socket connection broken")
            total_sent += sent

    @staticmethod
    def get_local_address():
        """
        クライアント側のIP取得
        簡易版：実際にsocketでつないでいるIPとは限らない。
        :return:
        """
        return socket.gethostbyname(socket.gethostname())

    @staticmethod
    def __get_msg_len(len_str):
        """
        4byte文字列からメッセージ長を取得
        :param len_str:
        :return:
        """
        # msg_len = ord(len_str[0]) & 0xff
        # msg_len |= (ord(len_str[1]) & 0xff) << 8
        # msg_len |= (ord(len_str[2]) & 0xff) << 16
        # msg_len |= (ord(len_str[3]) & 0xff) << 24

        msg_len = len_str[0] & 0xff
        msg_len |= (len_str[1] & 0xff) << 8
        msg_len |= (len_str[2] & 0xff) << 16
        msg_len |= (len_str[3] & 0xff) << 24
        return msg_len

    @staticmethod
    def __create_len_array(msg):
        """
        メッセージ長を生成
        :param msg:
        :return:
        """
        msg_len = len(msg)
        ret = bytearray([])
        ret.append(msg_len & 0xff)
        ret.append((msg_len >> 8) & 0xff)
        ret.append((msg_len >> 16) & 0xff)
        ret.append((msg_len >> 24) & 0xff)
        return ret
