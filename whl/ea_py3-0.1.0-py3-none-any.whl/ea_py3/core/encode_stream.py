# -*- coding: utf-8 -*-
import random
__author__ = 'ishii.y'


class EncodeStream(object):
    """
    送信用ストリームクラス
    """
    # 4byte文字列の長さを表す
    c_aby4BytesLen = b'\x04\x00\x00\x00'
    c_abyHeader = b'DWODS NETWORK STREAM\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00'

    def __init__(self):
        self.byte_array = bytearray([])

    def __write(self, byte):
        """
        byteを追加
        :param byte: 0-255の整数
        :return:
        """
        self.byte_array.append(byte)

    def __write_bytes(self, byte_array, offset, length):
        if length == 0:
            return
        if offset < 0 \
                or (offset > len(byte_array)) \
                or length < 0 \
                or ((offset + length) > len(byte_array)) \
                or ((offset + length) < 0):
            raise IndexError("out of index.")
        self.byte_array += byte_array[offset: offset + length]
        return

    def __write_plain_4bytes(self, value):
        """
        4byteの値を書き込む
        :param value:
        :return:
        """
        self.__write(value & 0xff)
        self.__write((value >> 8) & 0xff)
        self.__write((value >> 16) & 0xff)
        self.__write((value >> 24) & 0xff)

    def reset(self):
        self.byte_array = bytearray([])

    def size(self):
        return len(self.byte_array)

    def write_4bytes(self, value):
        """
        4byte値の書き込み専用
        :param value:
        :return:
        """
        self.__write_bytes(self.c_aby4BytesLen, 0, 4)
        self.__write_plain_4bytes(value)

    def write_string(self, value, encode):
        """
        文字列をbyte列に変換して登録
        :param value: unicode文字列
        :param encode:
        :return:
        """
        enc_value = value.encode(encode)
        # byte数+1
        self.__write_plain_4bytes(len(enc_value) + 1)
        self.__write_bytes(enc_value, 0, len(enc_value))
        self.__write(0)  # 終端

    def write_bytes(self, byte_array):
        """
        バイト列を登録
        :param byte_array:
        :return:
        """
        self.__write_plain_4bytes(len(byte_array))
        self.__write_bytes(byte_array, 0, len(byte_array))

    def to_byte_array(self):
        key = random.randrange(0, 2 ** 31)
        byte0 = key & 0xff
        byte1 = (key >> 8) & 0xff
        byte2 = (key >> 16) & 0xff
        byte3 = (key >> 24) & 0xff
        byte0 ^= byte1
        byte1 ^= byte2
        byte2 ^= byte3
        byte3 ^= byte0

        bytes_len = len(self.byte_array)

        byte_array = bytearray([])

        byte_array += self.c_abyHeader
        byte_array.append(bytes_len & 0xff)
        byte_array.append((bytes_len >> 8) & 0xff)
        byte_array.append((bytes_len >> 16) & 0xff)
        byte_array.append((bytes_len >> 24) & 0xff)
        byte_array.append(byte0)
        byte_array.append(byte1)
        byte_array.append(byte2)
        byte_array.append(byte3)

        mask = []
        for i in range(0, min(25, bytes_len)):
            mask.append((key >> i) & 0xff)
            value = self.byte_array[i] ^ mask[i]
            byte_array.append(value)

        for i in range(25, bytes_len):
            value = self.byte_array[i] ^ mask[i % 25]
            byte_array.append(value)

        return byte_array
