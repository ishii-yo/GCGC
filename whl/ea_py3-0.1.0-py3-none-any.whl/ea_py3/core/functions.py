# -*- coding: utf-8 -*-
__author__ = 'ishii.y'
"""
共通関数
"""


def convert_quotes(value):
    """
    single quoteをエスケープ
    serverに送るpythonコードのstringはsingle quateで統一しているため。
    :param value:
    :return:
    """
    return value.replace("'", "\\'")


def get_login_h(aby_login):
    return byte_to_int(aby_login, 0)


def get_login_date(aby_login):
    return byte_to_int(aby_login, 4)


def get_login_key(aby_login):
    return byte_to_int(aby_login, 8)


def get_login_oid(aby_login):
    return byte_to_int(aby_login, 12)


def get_login_proc(aby_login):
    return byte_to_int(aby_login, 16)


def byte_to_int(byte_array, idx):
    part0 = byte_array[idx + 0] & 0xff
    part1 = byte_array[idx + 1] & 0xff
    part2 = byte_array[idx + 2] & 0xff
    part3 = byte_array[idx + 3] & 0xff
    ret = part0
    ret |= (part1 << 8)
    ret |= (part2 << 16)
    ret |= (part3 << 24)
    return ret