# -*- coding: utf-8 -*-
from . import connection as connection
from . import py_interpreter as pi
from .. import dw_exception as ex
from .. import const
from . import functions as func
__author__ = 'ishii.y'


def create_and_login(server, port, user, pwd, client_ip, client_name, connect_type, locale, request_id):
    h = LoginHandle()
    h.login(server, port, user, pwd, client_ip, client_name, connect_type, locale, request_id)
    return h


class LoginHandle:
    ODS_FUNC_LOGIN = 1
    ODS_FUNC_LOGOUT = 2
    ODS_FUNC_GET_SERVER_INFO = 54

    CL_JAVA_API = 14
    CL_PYTHON_API = 15

    def __init__(self):
        self.server = ''
        self.port = 0
        self.connect_type = 0
        self.encode = 'utf-8'  # サーバーから返ってくる文字のエンコード
        self.locale = 0
        self.multilingual = False
        self.aby_login = None
        self.login_handle = 0
        self.date = 0
        self.key = 0
        self.oid = 0
        self.proc = 0
        self.server_edition = 0
        self.multiview_table_count = 0
        self.max_access_count = 0
        self.version = 0
        self.product_version = ''
        self.signal = 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.logout()

    def login(self, server, port, user, pwd, client_ip, client_name, connect_type, locale, request_id):
        self.server = server
        self.port = port
        self.connect_type = connect_type
        self.encode = 'utf-8'
        if connect_type < const.SERVER_VERSION_30:
            self.encode = 'cp932'
        self.locale = locale

        with connection.connect(self.server, self.port, self.locale, self.encode) as con:
            self.multilingual = con.is_multilingual()
            con.write_4bytes(con.get_session_handle())
            con.write_4bytes(self.ODS_FUNC_LOGIN)

            connect_info_str = user + '\t' + con.get_local_address() + '\t'
            if connect_type >= const.SERVER_VERSION_30:
                connect_info_str += str(self.CL_PYTHON_API)
                connect_info_str += '\t' + client_ip
                connect_info_str += '\t' + client_name
                if request_id is not None:
                    connect_info_str += '\t' + request_id
            con.write_string(connect_info_str)
            con.write_string(pwd)
            con.send()
            con.recv()
            ret = con.read_4bytes()
            if ret >= 0x80000000:
                raise ex.create(ret, self.locale)
            self.aby_login = con.read_bytes()
            self.login_handle = func.get_login_h(self.aby_login)
            self.date = func.get_login_date(self.aby_login)
            self.key = func.get_login_key(self.aby_login)
            self.oid = func.get_login_oid(self.aby_login)
            self.proc = func.get_login_proc(self.aby_login)
            self.__init_info()

    def logout(self):
        if self.aby_login is None:
            return
        try:
            with connection.connect(self.server, self.port, self.locale, self.encode) as con:
                con.write_4bytes(con.get_session_handle())
                con.write_4bytes(self.ODS_FUNC_LOGOUT)
                con.write_bytes(self.aby_login)
                con.send()
                con.recv()
                ret = con.read_4bytes()
                if ret >= 0x80000000:
                    raise ex.create(ret, self.locale)
        finally:
            self.aby_login = None
            self.login_handle = 0
            self.date = 0
            self.key = 0
            self.oid = 0
            self.proc = 0

    def __init_info(self):
        """
        サーバー情報の初期化
        :return:
        """
        if self.proc < const.SERVER_VERSION_30SP1:
            # 3.0以前は処理しない。
            return
        version_str = self.get_server_info()
        self.version = self.__get_server_version(version_str)
        self.product_version = version_str

    def get_server_info(self):
        version = ''
        with connection.connect(self.server, self.port, self.locale, self.encode) as con:
            con.write_4bytes(con.get_session_handle())
            con.write_4bytes(self.ODS_FUNC_GET_SERVER_INFO)
            con.write_bytes(self.aby_login)
            con.send()
            con.recv()
            ret = con.read_4bytes()
            if ret >= 0x80000000:
                raise ex.create(ret, self.locale)
            self.server_edition = con.read_4bytes()
            self.multiview_table_count = con.read_4bytes()
            version = con.read_string()
            if self.multilingual:
                self.max_access_count = con.read_4bytes()
        return version

    def get_login_handle(self):
        return self.login_handle

    @staticmethod
    def __get_server_version(version_str):
        ret = const.SERVER_VERSION_50
        version_info = [int(x) for x in version_str.split('.')]
        if version_info[0] == 5:
            ret = const.SERVER_VERSION_50
        elif version_info[0] == 4:
            if version_info[1] == 0:
                if version_info[2] == 0:
                    ret = const.SERVER_VERSION_40
                elif version_info[2] == 1:
                    ret = const.SERVER_VERSION_40SP1
            elif version_info[1] == 1:
                ret = const.SERVER_VERSION_41
            elif version_info[1] == 2:
                ret = const.SERVER_VERSION_42

        elif version_info[0] == 3:
            # 手抜き
            ret = const.SERVER_VERSION_30SP3
        return ret

    def create_interpreter(self, signal):
        py = pi.connect(self.server, self.port, self.locale, self.encode, self.aby_login, signal)
        self.signal = signal
        return py

    def get_locale(self):
        return self.locale

    def is_multilingual(self):
        return self.multilingual

    def get_server_version(self):
        return self.version
