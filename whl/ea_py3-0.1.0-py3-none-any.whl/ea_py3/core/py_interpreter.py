# -*- coding: utf-8 -*-
from . import connection as connection
from .. import dw_exception as ex
from ..core import py_signal as ps
from ..core import functions as func
__author__ = 'ishii.y'


def connect(server, port, locale, encode, aby_login, signal):
    py = Python()
    py.connect(server, port, locale, encode, aby_login, signal)
    return py


class Python(object):
    def __init__(self):
        self.con = None
        self.aby_login = None
        self.h_python = 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

    def connect(self, server, port, locale, encode, aby_login, signal):
        self.aby_login = aby_login
        self.con = connection.connect(server, port, locale, encode)
        try:
            self.con.write_4bytes(self.con.get_session_handle())
            self.con.write_4bytes(signal)
            if signal != ps.Signal.connect_pyl and signal != ps.Signal.connect_pyl2_3:
                self.con.write_bytes(self.aby_login)
            self.con.send()

            self.con.recv()
            ret = self.con.read_4bytes()
            if ret >= 0x80000000:
                raise ex.create(ret, locale)

            self.con.read_4bytes()  # skip 4bytes

            self.con.write_4bytes(self.con.get_session_handle())
            self.con.write_4bytes(ps.PyFunction.create_handle)
            self.con.send()

            self.con.recv()
            ret = self.con.read_4bytes()
            if ret >= 0x80000000:
                raise ex.create(ret, locale)
            self.h_python = self.con.read_4bytes()

            com = 'login_handle =[%d, %d, %d, %d]\n' \
                  'database_handle=0\n' % (func.get_login_h(self.aby_login),
                                           func.get_login_date(self.aby_login),
                                           func.get_login_key(self.aby_login),
                                           func.get_login_oid(self.aby_login))
            self.run_string(com)
        except Exception as e:
            self.con.disconnect()
            raise e

    def disconnect(self):
        if self.h_python == 0:
            return
        if self.con is not None:
            self.con.disconnect()
        self.h_python = 0

    def run_string(self, value):
        self.con.write_4bytes(self.con.get_session_handle())
        self.con.write_4bytes(ps.PyFunction.run_string)
        self.con.write_4bytes(self.h_python)
        self.con.write_string(value)
        self.con.send()

        self.con.recv()
        ret = self.con.read_4bytes()
        if ret >= 0x80000000:
            raise ex.create(ret, self.con.get_locale())

    def get_value_string(self, value):
        self.con.write_4bytes(self.con.get_session_handle())
        self.con.write_4bytes(ps.PyFunction.get_value_string)
        self.con.write_4bytes(self.h_python)
        self.con.write_string(value)
        self.con.send()

        self.con.recv()
        ret = self.con.read_4bytes()
        if ret >= 0x80000000:
            raise ex.create(ret, self.con.get_locale())
        ret = self.con.read_string()
        return ret

    def get_value_int(self, value):
        self.con.write_4bytes(self.con.get_session_handle())
        self.con.write_4bytes(ps.PyFunction.get_value_int)
        self.con.write_4bytes(self.h_python)
        self.con.write_string(value)
        self.con.send()

        self.con.recv()
        ret = self.con.read_4bytes()
        if ret >= 0x80000000:
            raise ex.create(ret, self.con.get_locale())
        ret = self.con.read_4bytes()
        return int(ret)
