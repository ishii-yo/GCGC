# -*- coding: utf-8 -*-
__author__ = 'ishii.y'


class Signal:
    connect = 0xffffff00
    pylsql = 0xfffffefc
    disconnect = 0xfffffeff

    connect_pyl = 0xfffffefe
    connect_pyl2_3 = 0xfffffef5

    def __init__(self):
        pass


class PyFunction:
    create_handle = 0
    run_string = 2
    get_value_string = 3
    get_value_int = 6

    def __init__(self):
        pass