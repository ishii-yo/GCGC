# -*- coding: utf-8 -*-
__author__ = 'ishii.y'


def default_db_info(db_name):
    db = DatabaseInfo()
    db.name = db_name
    return db


def create(db_info):
    db = DatabaseInfo()
    db.name = db_info['name']
    db.path = db_info['path']
    db.rs = (db_info['rs'] == 1)
    db.null = db_info['null']
    db.enabled = (db_info['enabled'] == 0)
    db.dat_mem_size = db_info['dat_mem_size']
    db.dat_page_size = db_info['dat_page_size'] / 1024
    db.crx_mem_size = db_info['crx_mem_size']
    db.crx_page_size = db_info['crx_page_size'] / 1024
    db.exists = db_info['exists']
    return db


class DatabaseInfo:
    """
    DB情報の構造体
    """
    def __init__(self):
        self.name = ''
        self.path = ''
        self.rs = False
        self.null = 0
        self.enabled = False
        self.dat_mem_size = 0
        self.dat_page_size = 0
        self.crx_mem_size = 0
        self.crx_page_size = 0
        self.exists = False

    def __str__(self):
        return 'name=%s,path=%s,rs=%s,null=%d,enabled=%s,dat_mem_size=%d,dat_page_size=%s,' \
               'crx_mem_size=%s,crx_page_size=%s,exists=%s' % (self.name, self.path, self.rs, self.null,
                                                               self.enabled, self.dat_mem_size, self.dat_page_size,
                                                               self.crx_mem_size, self.crx_page_size, self.exists)
