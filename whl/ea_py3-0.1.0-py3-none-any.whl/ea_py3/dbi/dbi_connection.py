# -*- coding: utf-8 -*-
from .. import dw_exception as ex
from ..core import py_signal as ps
from ..core import dw_connection as dw_con
from ..core import functions as func
from ..dbi import dbi_curor as cur

__author__ = 'ishii.y'


def connect(server, port, user, pwd, db):
    """
    サーバーへのログイン及びDBへconnectしたDwDbiConnectionを返す。
    :param server:
    :param port:
    :param user:
    :param pwd:
    :param db:
    :return:
    """
    con = DwDbiConnection()
    con.login_and_connect(server, port, user, pwd, db)
    return con


def login(server, port, user, pwd):
    """
    サーバーへのログインしたDwDbiConnectionを返す。
    :param server:
    :param port:
    :param user:
    :param pwd:
    :return:
    """
    con = DwDbiConnection()
    con.login(server, port, user, pwd)
    return con


class DwDbiConnection(object):

    def __init__(self):
        self.con = dw_con.DwConnection()
        self.db = ''
        self.h_db = 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def login_and_connect(self, server, port, user, pwd, db):
        self.con.login(server, port, user, pwd, ps.Signal.pylsql)
        try:
            self.connect(db)
        except Exception as e:
            self.con.logout()
            raise e

    def login(self, server, port, user, pwd):
        self.con.login(server, port, user, pwd, ps.Signal.pylsql)

    def connect(self, db):
        """
        db connect。connectしている場合はcloseしてからconnect。
        :param:db
        :return:
        """
        self.close_db()
        self.h_db = self.con.connect(db)
        self.db = db

    def close(self):
        """
        DBのdisconnect及びログアウト。
        :return:
        """
        try:
            self.close_db()
        finally:
            self.con.logout()

    def close_db(self):
        """
        dbクローズ。connectしていない場合は何もしない。
        :return:
        """
        self.con.close_db(self.h_db)
        self.h_db = 0

    def cursor(self):
        return cur.create(self)

    def get_db_handle(self):
        return self.h_db

    def get_server_version(self):
        return self.con.get_server_version()

    def get_error_code(self, module):
        return self.con.get_error_code(module)

    def run_string(self, value):
        return self.con.python.run_string(value)

    def get_value_string(self, value):
        return self.con.python.get_value_string(value)

    def get_value_int(self, value):
        return self.con.python.get_value_int(value)

    def python_is_none(self):
        """
        python interpreterが存在するか
        :return:
        """
        return self.con.python is None

    def get_database_list(self):
        return self.con.get_database_list()

    def get_table_list(self, table):
        return self.con.get_table_list(table)

