# -*- coding: utf-8 -*-
from .. import column_info as dwcol
from .. import dw_exception as ex
from .. import const
from ..core import functions as func


__author__ = 'ishii.y'


def create(con):
    cur = Cursor()
    cur.con = con
    return cur


class Cursor:
    EXEC_NORMAL = 0
    EXEC_INMEMORY = 1

    def __init__(self):
        self.con = None
        self.h_rs = 0
        self.record_cont = 0
        self.exec_type = self.EXEC_NORMAL
        self.columns = []
        self.multiview_warning = True
        self.pos = 1

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def execute(self, sql):
        """
        SQL実行
        :param sql:
        :return:
        """

        if self.h_rs != 0:
            self.close()

        mview_warning = 'DWPyDBM.warning'
        if self.con.get_server_version() < const.SERVER_VERSION_30:
            mview_warning = '0'
        exec_type = 'rs_info[5]'
        if self.con.get_server_version() < const.SERVER_VERSION_50:
            exec_type = '0'

        sql = func.convert_quotes(sql)
        code = "s_recordset_handle='0'\n" \
               "recordset_handle=DWPyDBM.Execute(login_handle,%d,'%s')\n" \
               "if DWPyDBM.error >= 0  and recordset_handle != 0:\n" \
               "  s_recordset_handle=str(recordset_handle)\n" \
               "  mview_warning=%s\n" \
               "  rs_info=DWPyDBM.GET_RSINFO(%d,recordset_handle)\n" \
               "  if DWPyDBM.error >= 0:\n" \
               "    rs_cnt=rs_info[3]\n" \
               "    exec_type=%s\n" \
               "    meta_data=DWPyDBM.GET_METADATA(%d,recordset_handle)\n" \
               "    if DWPyDBM.error >= 0:\n" \
               "      res_list=''\n" \
               "      for item in meta_data:\n" \
               "        res_list=res_list+str(item[0])+'\\x01'\n" \
               "        res_list=res_list+str(item[1])+'\\x01'\n" \
               "        res_list=res_list+str(item[2])+'\\x01'\n" \
               "        res_list=res_list+str(item[3])+'\\x01'\n" \
               "        res_list=res_list+str(item[4])+'\\x01'\n" \
               "        res_list=res_list+str(item[5])+'\\x01'\n" \
               "        res_list=res_list+item[6]+'\\x01'\n" \
               "        res_list=res_list+item[7]+'\\x01'\n" \
               "        res_list=res_list+item[8]+'\\x01'\n" \
               "        res_list=res_list+item[9]+'\\x01'\n" \
               "        res_list=res_list+str(item[10])+'\\x01'\n" \
               "        res_list=res_list+str(item[11])+'\\x02'\n" % \
               (self.con.get_db_handle(), sql, mview_warning, self.con.get_db_handle(), exec_type,
                self.con.get_db_handle())

        self.con.run_string(code)
        ret, msg = self.con.get_error_code('DWPyDBM')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        handle_str = self.con.get_value_string("s_recordset_handle")
        self.h_rs = int(handle_str)
        if self.h_rs == 0:
            return

        self.record_cont = self.con.get_value_int("rs_cnt")
        self.exec_type = self.con.get_value_int("exec_type")
        meta_str = self.con.get_value_string("res_list")

        col_strs = meta_str.split('\x02')
        for col_str in col_strs[:len(col_strs)-1]:
            self.columns.append(dwcol.create_from_py_result(col_str))

        self.multiview_warning = (self.con.get_value_int("mview_warning") == 1)

    def fetchmany(self, num):
        """
        fetch
        :param num: fetch行数
        :return:
        """
        code = "recordset=DWPyDBM.RS_FetchODBC(%d,%d,%d,%d)\n" % (self.con.get_db_handle(), self.pos, num, self.h_rs)
        self.con.run_string(code)
        ret, msg = self.con.get_error_code('DWPyDBM')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        code = "rs=recordset[1]\n"
        self.con.run_string(code)
        record_set_str = self.con.get_value_string("rs")
        record_set = self.get_record_set(record_set_str)
        self.pos += len(record_set)
        return record_set

    def fetchall(self):
        """
        全行fetch
        :return:
        """
        return self.fetchmany(0)

    def get_columns(self):
        return self.columns

    def column_names(self):
        return [col.display for col in self.columns]

    @classmethod
    def get_record_set(cls, rec_str):
        """
        取得したレコードセット文字列からレコードセットを生成する。
        ２次元のリスト形式
        :param rec_str:
        :return:
        """
        row_dlm = '\x02'
        col_dlm = '\x01'
        null_str = '\x19'
        ret = []
        for row in rec_str.split(row_dlm):
            ret.append([None if cel == null_str else cel for cel in row.split(col_dlm)])
        ret.pop()  # 最終行を削除
        return ret

    def close(self):
        """
        RS_HANDLEのCLOSE
        :return:
        """
        if self.h_rs == 0:
            return
        if self.con is None:
            return
        if self.con.python_is_none():
            return
        try:
            code = "DWPyDBM.RS_Close(%d,%d)\n" % (self.con.get_db_handle(), self.h_rs)
            self.con.run_string(code)
            ret, msg = self.con.get_error_code("DWPyDBM")
            if ret >= 0x80000000:
                raise ex.create_with_msg(ret, msg)

        finally:
            self.columns = []
            self.h_rs = 0
            self.pos = 1
