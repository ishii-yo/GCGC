# -*- coding: utf-8 -*-
from . import const
__author__ = 'ishii.y'


def create(code, locale):
    msg = get_error_message(code, locale)
    return DwException(code, msg)


def create_with_msg(code, msg):
    return DwException(code, msg)


def get_error_message(code, locale):
    err_code = code & 0xf0ffffff
    ret = ''
    if locale == const.LOCALE_JPN:
        if err_code == const.DWAPI_ERR_SUCCESS:
            ret = "正常に処理が終了しました。"
        if err_code == const.DWAPI_NO_SUPPORT:
            ret = "古いバージョンのためサポートしていません。"
        if err_code == const.DWAPI_DBM_ERR_ILLEGAL_CHARACTER:
            ret = "使用できない文字が指定されています。"
    elif locale == const.LOCALE_ENG:
        ret = 'English is no support.(%s)' % hex(code)
    elif locale == const.LOCALE_CHN:
        ret = 'Chinese is no support.(%s)' % hex(code)

    if ret == '':
        ret = 'Error code(%s).' % hex(code)
    return ret


class DwException(Exception):
    def __init__(self, code, msg):
        super(DwException, self).__init__(msg)
        self.code = code

