# -*- coding: utf-8 -*-
from enum import IntEnum
import sys
import configparser
from . import log_info

__author__ = 'ishii.y'


class RangeType(IntEnum):
    DATETIME = 1  # 日時
    SEQUENCE_NUMBER = 2  # シーケンス番号


def create(max_count=100, range_type=RangeType.DATETIME, start_time='', end_time='', start_seq_num=0, file_name=None):
    """
    Condistionの生成
    :param max_count:
    :param range_type:
    :param start_time:
    :param end_time:
    :param start_seq_num:
    :param file_name:
    :return:
    """
    cond = Condition()
    cond.range = RangeCondition.create(max_count, range_type, start_time, end_time, start_seq_num)
    if file_name is not None:
        cond.data = DataCondition.create_from_lds(file_name)
    return cond


class Condition:
    """
    Log Downloadの条件
    """
    def __init__(self):
        self.range = RangeCondition()
        self.data = DataCondition()

    def py_run_str(self):
        """
        pythonインタプリターに引き渡す文字列
        :return:
        """
        cond = list()
        cond.append(self.range.max_count)
        cond.append(len(self.data.logs))
        cond.append(len(self.data.cols))
        cond.append(len(self.data.filters))
        cond.append(int(self.range.range_type))
        cond.append(self.range.start_range())
        cond.append(self.range.end_range())
        cond.append(self.data.logs)
        cond.append(self.data.col_id_list())
        cond.append(self.data.filters)
        return str(cond)

    def csv_header(self):
        return self.data.csv_header()

    def column_ids(self):
        return self.data.column_ids()


class RangeCondition:
    """
    ログ取得範囲関する条件。件数、日時など
    注）バッチで実行毎に指定する条件。
    """
    min_seq = 0  # シーケンス番号の最小値
    max_seq = sys.maxsize - 1  # シーケンス番号の最大値
    max_date = '300012312359999'  # 日付の最大値

    def __init__(self):
        self.max_count = 100  # 最大取得件数
        self.range_type = RangeType.DATETIME  # 取得タイプ(RangeType): 日時, シーケンス番号
        self.start_time = ''  # スタート時刻(YYYY/MM/DD HH:mm) 取得タイプ=日時で使用
        self.end_time = ''   # 終了時刻(YYYY/MM/DD HH:mm)取得タイプ=日時で使用
        self.start_seq_num = 0  # 開始シーケンス番号　取得タイプ=シーケンス番号で使用
        self.date_dlm = '/'
        self.time_dlm = ':'

    @classmethod
    def create(cls, max_count=100, range_type=RangeType.DATETIME, start_time='', end_time='', start_seq_num=0):
        """
        RangeConditionの生成
        :param max_count:
        :param range_type:
        :param start_time:
        :param end_time:
        :param start_seq_num:
        :return:
        """
        cond = RangeCondition()
        cond.max_count = max_count
        cond.range_type = range_type
        cond.start_time = start_time
        cond.end_time = end_time
        cond.start_seq_num = start_seq_num
        return cond

    def start_range(self):
        """
        開始条件を出力
        :return:
        """
        if self.range_type == RangeType.SEQUENCE_NUMBER:
            return str(self.start_seq_num)
        return '%s00000' % self.__convert_timestamp(self.start_time)

    def end_range(self):
        """
        終了条件を出力
        :return:
        """
        if self.range_type == RangeType.SEQUENCE_NUMBER:
            return str(self.max_seq)
        if self.end_time == '':
            return self.max_date
        return '%s59999' % self.__convert_timestamp(self.end_time)

    def __convert_timestamp(self, timestamp):
        """
        YYYY/MM/DD HH:mm形式を、YYYYMMDDHHmmに変換
        """
        conv = timestamp.replace(self.date_dlm, '')
        conv = conv.replace(self.time_dlm, '')
        conv = conv.replace(' ', '')
        return conv


class DataCondition:
    """
    ログ種別、カラム、抽出条件に関する情報
    注）ldsファイルに保存される情報
    """

    def __init__(self):
        self.logs = log_info.all_log_ids()  # 取得するログID
        self.cols = log_info.all_cols  # 取得するカラム情報
        self.cols_name_cap = log_info.default_name_cap()
        self.filters = []  # 抽出条件  [[FILTERn_LEVEL, 'FILTERn_COL_ID', FILTERn_OPERATION, 'FILTERn_DATA',],[..],..]

    @classmethod
    def create_from_lds(cls, file_name):
        """
        ldsファイルから生成
        :param file_name:
        :return:
        """
        cond = DataCondition()
        config = configparser.ConfigParser()
        config.read_file(open(file_name, 'r', encoding='utf-8'))
        log_id_count = int(config['DOWNLOAD_LOG']['LOG_ID_COUNT'])
        col_count = int(config['DOWNLOAD_LOG']['COL_COUNT'])
        filter_count = int(config['DOWNLOAD_LOG']['FILTER_COUNT'])
        cols_name_cap = config['DOWNLOAD_LOG']['COLS_NAME_CAP'].strip('"')

        cond.cols_name_cap = cols_name_cap
        # ログ種別取得
        cond.logs = []
        for i in range(log_id_count):
            log_id = 'LOG_IDS%d' % i
            cond.logs.append(config['DOWNLOAD_LOG'][log_id].strip('"'))

        # カラム種別取得
        cond.cols = []
        for i in range(col_count):
            cols = 'COLS%d' % i
            cols_cap = 'COLS_CAP%d' % i
            cols_type = 'COLS_TYPE%d' % i
            cond.cols.append(
                dict(id=config['DOWNLOAD_LOG'][cols].strip('"'),
                     cap=config['DOWNLOAD_LOG'][cols_cap].strip('"'),
                     type=int(config['DOWNLOAD_LOG'][cols_type]))
            )

        # フィルター情報取得
        cond.filters = []
        for i in range(filter_count):
            filter_level = 'FILTER%d_LEVEL' % i
            filter_col_id = 'FILTER%d_COL_ID' % i
            filter_operation = 'FILTER%d_OPERATION' % i
            filter_data = 'FILTER%d_DATA' % i
            cond.filters.append([
                int(config['DOWNLOAD_LOG'][filter_level]),
                config['DOWNLOAD_LOG'][filter_col_id].strip('"'),
                int(config['DOWNLOAD_LOG'][filter_operation]),
                config['DOWNLOAD_LOG'][filter_data].strip('"'),
            ])

        return cond

    def col_id_list(self):
        return [x['id'] for x in self.cols]

    def csv_header(self):
        """
        CSV用のカラム名のリスト
        :return:
        """
        return [self.cols_name_cap] + [x['cap'] for x in self.cols]

    def column_ids(self):
        """
        カラムIDのリスト
        :return:
        """
        return [log_info.default_name_id()] + [x['id'] for x in self.cols]



