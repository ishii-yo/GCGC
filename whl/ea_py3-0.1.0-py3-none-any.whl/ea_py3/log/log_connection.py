# -*- coding: utf-8 -*-
from ..core import dw_connection as dw_con
from ..core import py_signal as ps
from . import log_operator

__author__ = 'ishii.y'


def login(server, port, user, pwd):
    """
    サーバーへのログインしたDwLogConnectionを返す。
    :param server:
    :param port:
    :param user:
    :param pwd:
    :return:
    """
    con = DwLogConnection()
    con.login(server, port, user, pwd)
    return con


class DwLogConnection(object):

    def __init__(self):
        self.con = dw_con.DwConnection()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.logout()

    def login(self, server, port, user, pwd):
        self.con.login(server, port, user, pwd, ps.Signal.pylsql)

    def logout(self):
        """
        ログアウト。
        :return:
        """
        self.con.logout()

    def get_error_code(self, module):
        return self.con.get_error_code(module)

    def run_string(self, value):
        return self.con.python.run_string(value)

    def get_value_string(self, value):
        return self.con.python.get_value_string(value)

    def get_value_int(self, value):
        return self.con.python.get_value_int(value)

    def operator(self, condition):
        return log_operator.create(self, condition)

