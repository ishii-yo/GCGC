# -*- coding: utf-8 -*-
import os
from collections import namedtuple
import struct
from operator import itemgetter
import glob
import csv
from . import log_info

__author__ = 'ishii.y'


def create_table_sql(table_name):
    """
    logに対応したテーブルのcreate table文の作成
    :param table_name:
    :return:
    """
    sql = 'create table %s (\n' % table_name
    for v in log_info.csv_col_info():
        sql += '%s %s' % (v[0], v[1])
        if v[1] == 'NUMERIC':
            sql += '(%d,%d)' % (v[2], v[3])
        sql += ',\n'
    sql = sql[:len(sql)-2]
    sql += ');'
    return sql


def create_vtb(output_file):
    """
    logに対応したVTBファイル作成。
    :param output_file:
    :return:
    """
    v = VtbCreator()
    v.create_vtb(output_file)


def converter(target_dir):
    """
    log conveterの生成
    :param target_dir:対象ディレクトリ又は、内部ログファイル名(拡張子なし)
    :return:
    """
    return LogConverter(target_dir)


class LogConverter:
    """
    内部ログを変換
    """
    def __init__(self, target_dir):
        self.files = self.__log_files(target_dir)

    def stream(self):
        """
        ログを1行づつ返すgenerator。
        :return:
        """
        for log_file in self.files:
            log = MergedLog.create(log_file)
            for row in log.get_rows():
                yield row

    def write_csv(self, output_file, header=False):
        """
        全ログを1ファイルに出力
        :param output_file:
        :param header:
        :return:
        """
        with open(output_file, 'w') as f:
            writer = csv.writer(f, lineterminator='\n', quotechar='"', quoting=csv.QUOTE_ALL)
            if header:
                writer.writerow(MergedLog.get_csv_header())
            for log_file in self.files:
                log = MergedLog.create(log_file)
                for row in log.get_rows():
                    writer.writerow(row)

    def write_csv_per_file(self, output_dir, header=False):
        """
        ファイルごとにCSV出力
        :param output_dir:
        :param header:
        :return:
        """
        for log_file in self.files:
            log = MergedLog.create(log_file)
            output_file = os.path.join(output_dir, log.get_base_name() + '.csv')
            with open(output_file, 'w') as f:
                writer = csv.writer(f, lineterminator='\n', quotechar='"', quoting=csv.QUOTE_ALL)
                if header:
                    writer.writerow(MergedLog.get_csv_header())
                for row in log.get_rows():
                    writer.writerow(row)

    @classmethod
    def __log_files(cls, target_dir):
        files = cls.__get_files(target_dir, '/*.ilf')
        return [os.path.splitext(x)[0] for x in files]

    @classmethod
    def __get_files(cls, target_dir, pattern):
        """
        指定ディレクトリから内部ログファイルのリストを取得
        ファイル名の場合は、そのまま格納
        :param target_dir:
        :param pattern:
        :return:
        """
        if os.path.isfile(target_dir):
            return [target_dir]
        file_list = [(x, os.path.getmtime(x)) for x in glob.glob(target_dir + pattern) if os.path.isfile(x)]
        # 更新日付でソート。なるべく時系列でデータが並ぶように
        return [x[0] for x in sorted(file_list, key=itemgetter(1))]


class MergedLog:
    """
    ilfとilmファイルがマージされたログ
    """

    def __init__(self, file_name):
        self.file_name = file_name
        self.ilf = InnerLog.create(file_name + '.ilf')
        self.ilm = InnerLog.create(file_name + '.ilm')
        if len(self.ilf.rows) != len(self.ilm.rows):
            msg = 'log length is different[file=%s,ilf=%d,ilm=%d]' % (file_name, len(self.ilf.rows), len(self.ilm.rows))
            raise ValueError(msg)
        self.log_type = self.__get_log_type(self.get_base_name())

    @classmethod
    def __get_log_type(cls, file_name):
        """
        ファイル名からログ種別を取得する。
        :param file_name:
        :return:
        """
        for x in log_info.all_logs:
            if file_name.find(x['prefix']) == 0:
                return x['id']
        return ''

    @staticmethod
    def create(file_name):
        """
        対象ファイル名。拡張子なし
        :param file_name:
        :return:
        """
        return MergedLog(file_name)

    def get_rows(self):
        """
        ログを1行づつ返すgenerator
        :return:
        """
        for ilf, ilm in zip(self.ilf.rows, self.ilm.rows):
            if ilf.seq_num != ilm.seq_num:
                msg = 'sequence number is not match.[file=%s,ilf.seq_num=%d,ilm.seq_num=%d]'\
                      % (self.file_name, ilf.seq_num, ilm.seq_num)
                raise ValueError(msg)
            yield self.__get_row(ilf, ilm)

    @classmethod
    def get_csv_header(cls):
        return [x[0] for x in log_info.csv_col_info()]

    def get_base_name(self):
        return os.path.basename(self.file_name)

    def __get_row(self, ilf, ilm):
        """
        1行分取得
        :param ilf:
        :param ilm:
        :return:
        """
        ret = []
        for item in self.get_csv_header():
            # 固定部
            if item in log_info.col_map['COMMON']:
                ret.append(self.__get_ilf_value(ilf, item))
                continue
            # 可変部
            try:
                idx = log_info.col_map[self.log_type].index(item)
                ret.append(ilm.msgs[idx])
            except ValueError:
                ret.append('')
        return ret

    def __get_ilf_value(self, ilf, col_name):
        """
        固定部の値を取得する。
        :param col_name:
        :param ilf:
        :return:
        """
        if col_name == 'log_name':
            return self.log_type
        if col_name == 'cl_timestamp':
            return self.__get_datetime_str(ilf.date_time)
        if col_name == 'cl_date':
            return self.__get_date_str(ilf.date_time)
        if col_name == 'cl_time':
            return self.__get_time_str(ilf.date_time)
        if col_name == 'year':
            return ilf.date_time[:4]
        if col_name == 'month':
            return ilf.date_time[4:6]
        if col_name == 'day':
            return ilf.date_time[6:8]
        if col_name == 'hour':
            return ilf.date_time[8:10]
        if col_name == 'minute':
            return ilf.date_time[10:12]
        if col_name == 'sequence_num':
            return ilf.seq_num
        if col_name == 'host_id':
            return ilf.host_id
        if col_name == 'request_id':
            return ilf.request_id
        return ''

    @staticmethod
    def __get_datetime_str(d):
        return '%s/%s/%s %s:%s:%s.%s' % (d[:4], d[4:6], d[6:8], d[8:10], d[10:12], d[12:14], d[14:])

    @staticmethod
    def __get_date_str(d):
        return '%s/%s/%s' % (d[:4], d[4:6], d[6:8])

    @staticmethod
    def __get_time_str(d):
        return '%s:%s:%s.%s' % (d[8:10], d[10:12], d[12:14], d[14:])


class InnerLog:
    def __init__(self, file_name):
        self.rows = []
        self.file_name = file_name
        if os.path.getsize(file_name) > 0:
            self.load(file_name)

    @classmethod
    def create(cls, file_name):
        log = None
        _, ext = os.path.splitext(file_name)
        if ext == '.ila':
            log = Ila(file_name)
        elif ext == '.ilf':
            log = Ilf(file_name)
        elif ext == '.ilm':
            log = Ilm(file_name)
        return log

    def load(self, file_name):
        pass

    @classmethod
    def bin_to_str(cls, b):
        """
        バイナリ文字列を文字列に変換
        末尾のnull終端を削除。
        :param b:
        :return:
        """
        # return b[:-1].decode('utf-8')
        return b.decode('utf-8').rstrip('\x00')

    @classmethod
    def to_str(cls, t, convert):
        ret = []
        for i, x in enumerate(t):
            if i in convert:
                ret.append(cls.bin_to_str(x))
                continue
            ret.append(x)
        return ret


class Ila(InnerLog):
    Ilarow = namedtuple('Ilarow', 'min_seqnum max_seqnum min_date_time max_date_time pad1 file_size')
    str_idx = [2, 3, 4]  # tupleの中で文字列変換する箇所

    def __init__(self, file_name):
        super().__init__(file_name)

    def load(self, file_name):
        with open(file_name, 'rb') as f:
            buf = f.read(64)
            # 文字列はnull終端を含む文字が格納される。
            t = struct.unpack('QQ18s18s4sQ', buf)
            t = self.to_str(t, self.str_idx)
            self.rows.append(self.Ilarow._make(t))


class Ilf(InnerLog):
    Ilfrow = namedtuple('Ilfrow', 'timestamp seq_num date_time host_id request_id msg_count msg_length msg_offset pad1')
    str_idx = [2, 3, 4, 8]  # tupleの中で文字列変換する箇所

    def __init__(self, file_name):
        super().__init__(file_name)

    def load(self, file_name):
        with open(file_name, 'rb') as f:
            for buf in iter(lambda: f.read(176), b''):
                # 文字列はnull終端を含む文字が格納される。
                t = struct.unpack('QQ18s64s64sHII4s', buf)
                t = self.to_str(t, self.str_idx)
                row = self.Ilfrow._make(t)
                self.rows.append(row)


class Ilm(InnerLog):
    Ilmrow = namedtuple('Ilmrow', 'seq_num msg_count msgs')

    def __init__(self, file_name):
        super().__init__(file_name)

    def load(self, file_name):
        with open(file_name, 'rb') as f:
            for buf in iter(lambda: f.read(10), b''):
                seq_num, msg_count = struct.unpack('QH', buf)
                msgs = []
                for i in range(msg_count):
                    msg_length = struct.unpack('I', f.read(4))
                    msg = struct.unpack(str(msg_length[0]) + 's', f.read(msg_length[0]))
                    # 文字列はnull終端を含む文字が格納される
                    msgs.append(self.bin_to_str(msg[0]))
                # padding
                # f.read(5)
                self.rows.append(self.Ilmrow._make((seq_num, msg_count, msgs)))


class VtbCreator:
    def __init__(self):
        template_dir = os.path.join(os.path.dirname(__file__), 'templates')
        temp_file = os.path.join(template_dir, 'ealog_temp.vtb')
        self.template_file = temp_file

    def create_vtb(self, output_file):
        """
        出力logに対応したVTBファイル作成。
        :param output_file:
        :return:
        """
        temp_file = self.template_file
        with open(temp_file, 'r') as rf:
            with open(output_file, 'w') as wf:
                for line in rf:
                    if line.strip().find('%%COL%%') >= 0:
                        for col_info in self.__create_vtb_col():
                            wf.write(col_info)
                        continue
                    wf.write(line)

    @classmethod
    def __create_vtb_col(cls):
        """
        カラム情報テンプレートに、カラムデータを埋めて返す。
        :return:
        """
        temp = 'Begin VirtualField\n' \
               'VirtualFieldName = "%s"\n' \
               'RealFieldName = "%s"\n' \
               'Type             = "%s"\n' \
               'Precision        = "%d"\n' \
               'Scale            = "%d"\n' \
               'Position         = "%d"\n' \
               'Expression       = ""\n' \
               'End VirtualField\n' \
               '\n'
        for i, col in enumerate(log_info.csv_col_info()):
            yield temp % (col[0], col[0], col[1], col[2], col[3], i + 1)