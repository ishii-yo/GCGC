# -*- coding: utf-8 -*-
__author__ = 'ishii.y'

"""
ログ項目や種別に関する情報
"""

# ログ種類
all_logs = [
    {'id': 'ERROR', 'prefix': 'error_'},
    {'id': 'COMMIT', 'prefix': 'commit_'},
    {'id': 'SQL', 'prefix': 'sql_'},
    {'id': 'OLAP', 'prefix': 'olap_'},
    {'id': 'IMPORT', 'prefix': 'import_'},
    {'id': 'IMPORT-TASK', 'prefix': 'import-task_'},
    {'id': 'ACCESS', 'prefix': 'access_'},
    {'id': 'OPERATION', 'prefix': 'operation_'},
    {'id': 'STATE', 'prefix': 'state_'},
    {'id': 'MONITOR.SYSTEM', 'prefix': 'monitor_system_'},
    {'id': 'MONITOR.DRSUMEA', 'prefix': 'monitor_drsumea_'},
    {'id': 'DTL.STAT', 'prefix': 'dtl_stat_'},
]


def all_log_ids():
    """
    全ログのID一覧
    :return:
    """
    return [x['id'] for x in all_logs]

# ログカラムの情報
all_cols = [{'id': 'TIMESTAMP', 'cap': '日時', 'type': 8, 'column': ('cl_timestamp', 'VARCHAR', 0, 0)},
            {'id': 'DATE', 'cap': '日付', 'type': 4, 'column': ('cl_date', 'DATE', 0, 0)},
            {'id': 'TIME', 'cap': '時間', 'type': 5, 'column': ('cl_time', 'TIME', 0, 0)},
            {'id': 'DATE_YYYY', 'cap': '年', 'type': 2, 'column': ('year', 'NUMERIC', 4, 0)},
            {'id': 'DATE_MM', 'cap': '月', 'type': 2, 'column': ('month', 'NUMERIC', 4, 0)},
            {'id': 'DATE_DD', 'cap': '日', 'type': 2, 'column': ('day', 'NUMERIC', 4, 0)},
            {'id': 'TIME_HH', 'cap': '時', 'type': 2, 'column': ('hour', 'NUMERIC', 4, 0)},
            {'id': 'TIME_MI', 'cap': '分', 'type': 2, 'column': ('minute', 'NUMERIC', 4, 0)},
            {'id': 'SEQNUM', 'cap': 'シーケンス値', 'type': 2, 'column': ('sequence_num', 'NUMERIC', 18, 0)},
            {'id': 'LH', 'cap': 'LH', 'type': 2, 'column': ('lh', 'NUMERIC', 18, 0)},
            {'id': 'ERRORCD', 'cap': 'エラーコード', 'type': 7, 'column': ('error_code', 'VARCHAR', 0, 0)},
            {'id': 'USER', 'cap': 'ユーザー', 'type': 1, 'column':  ('usr', 'VARCHAR', 0, 0)},
            {'id': 'CL_IP_EA', 'cap': 'IPアドレス', 'type': 1, 'column': ('ip_address', 'VARCHAR', 0, 0)},
            {'id': 'CLIENT_TYPE', 'cap': 'クライアント', 'type': 1, 'column': ('client', 'VARCHAR', 0, 0)},
            {'id': 'CONNECTION_ID', 'cap': 'コネクションID', 'type': 1, 'column': ('connection_id', 'VARCHAR', 0, 0)},
            {'id': 'MESSAGE', 'cap': 'メッセージ', 'type': 1, 'column': ('message', 'VARCHAR', 0, 0)},
            {'id': 'CL_IP_APP', 'cap': 'IPアドレス（CL）', 'type': 1, 'column': ('cl_ip_address', 'VARCHAR', 0, 0)},
            {'id': 'DATABASE', 'cap': 'データベース', 'type': 1, 'column': ('database', 'VARCHAR', 0, 0)},
            {'id': 'TABLE', 'cap': 'テーブル', 'type': 1, 'column': ('tbl', 'VARCHAR', 0, 0)},
            {'id': 'SQL', 'cap': 'SQL', 'type': 1, 'column': ('sql', 'VARCHAR', 0, 0)},
            {'id': 'AGG_ROWS', 'cap': '行項目', 'type': 1, 'column': ('row', 'VARCHAR', 0, 0)},
            {'id': 'AGG_COLS', 'cap': '列項目', 'type': 1, 'column': ('col', 'VARCHAR', 0, 0)},
            {'id': 'AGG_ITEMS', 'cap': '集計項目', 'type': 1, 'column': ('agg', 'VARCHAR', 0, 0)},
            {'id': 'SEARCH_COND', 'cap': '抽出条件式', 'type': 1, 'column': ('rtx', 'VARCHAR', 0, 0)},
            {'id': 'DRILL_COND', 'cap': '抽出条件式（ドリルダウン／アップ）', 'type': 1, 'column': ('rtx_drill', 'VARCHAR', 0, 0)},
            {'id': 'TARGET_ROWS', 'cap': '対象件数', 'type': 2, 'column': ('target_num', 'NUMERIC', 18, 0)},
            {'id': 'TOTAL_ROWS', 'cap': '総件数', 'type': 2, 'column': ('total_num', 'NUMERIC', 18, 0)},
            {'id': 'CROSS_ROWS', 'cap': 'クロス行数', 'type': 2, 'column': ('row_num', 'NUMERIC', 18, 0)},
            {'id': 'CROSS_COLS', 'cap': 'クロス列数', 'type': 2, 'column': ('col_num', 'NUMERIC', 18, 0)},
            {'id': 'ELAPSED_TIME', 'cap': '集計時間（秒）', 'type': 3, 'column': ('execute_time', 'NUMERIC', 33, 6)},
            {'id': 'LOG_TYPE', 'cap': '種類', 'type': 1, 'column': ('type', 'VARCHAR', 0, 0)},
            {'id': 'OPERATION', 'cap': '操作', 'type': 1, 'column': ('operation', 'VARCHAR', 0, 0)},
            {'id': 'PARAMETER', 'cap': 'パラメーター', 'type': 1, 'column': ('parameter', 'VARCHAR', 0, 0)},
            {'id': 'HOSTID', 'cap': 'ホスト識別子', 'type': 1, 'column': ('host_id', 'VARCHAR', 0, 0)},
            {'id': 'PFLOG_CLASS', 'cap': '指標分類', 'type': 1, 'column': ('index_class', 'VARCHAR', 0, 0)},
            {'id': 'PFLOG_NAME', 'cap': '指標名', 'type': 1, 'column': ('index_name', 'VARCHAR', 0, 0)},
            {'id': 'PFLOG_VALUE', 'cap': '指標値', 'type': 1, 'column': ('value', 'NUMERIC', 33, 6)},
            {'id': 'PFLOG_DETAIL', 'cap': '指標詳細', 'type': 1, 'column': ('detail', 'VARCHAR', 0, 0)},
            {'id': 'REQUEST_ID', 'cap': '要求識別子', 'type': 1, 'column': ('request_id', 'VARCHAR', 0, 0)},
            {'id': 'DTL_LOG_TIMESTAMP', 'cap': 'DTL_時刻', 'type': 6, 'column': ('dtl_time', 'VARCHAR', 0, 0)},
            {'id': 'DTL_LOG_CODE', 'cap': 'DTL_タイプ', 'type': 1, 'column': ('dtl_type', 'VARCHAR', 0, 0)},
            {'id': 'DTL_LOG_SERVER_IP', 'cap': 'DTL_サーバーIP', 'type': 1, 'column': ('dtl_server_ip', 'VARCHAR', 0, 0)},
            {'id': 'DTL_LOG_CLIENT_IP', 'cap': 'DTL_クライアントIP', 'type': 1, 'column': ('dtl_client_ip', 'VARCHAR', 0, 0)},
            {'id': 'DTL_LOG_FILE_ID', 'cap': 'DTL_ファイルID', 'type': 1, 'column': ('dtl_file_id', 'VARCHAR', 0, 0)},
            {'id': 'DTL_LOG_FILE_NAME', 'cap': 'DTL_ファイル名', 'type': 1, 'column': ('dtl_file_name', 'VARCHAR', 0, 0)},
            {'id': 'DTL_LOG_JOBTIME', 'cap': 'DTL_処理時間', 'type': 2, 'column': ('dtl_execute_time', 'NUMERIC', 33, 6)},
            {'id': 'DTL_LOG_JOBCOUNT', 'cap': 'DTL_処理数', 'type': 2, 'column': ('dtl_execute_num', 'NUMERIC', 18, 0)},
            {'id': 'DTL_LOG_JOBSTATUS', 'cap': 'DTL_ステータス', 'type': 2, 'column': ('dtl_status', 'NUMERIC', 18, 0)},
            {'id': 'DTL_LOG_JOB_TYPE', 'cap': 'DTL_処理種類', 'type': 1, 'column': ('dtl_execute_type', 'VARCHAR', 0, 0)}
            ]

# ログ名カラムの情報
log_name_info = {'id': 'LOG_NAME', 'cap': 'ログ名', 'type': 1, 'column': ('log_name', 'VARCHAR', 0, 0)}


def default_name_cap():
    return log_name_info['cap']


def default_name_id():
    return log_name_info['id']


def csv_col_info():
    return [log_name_info['column']] + [x['column'] for x in all_cols]


# ログ項目対照表
col_map = {
    'ACCESS': ('lh', 'usr', 'ip_address', 'cl_ip_address', 'client', 'message'),
    'COMMIT': ('lh', 'usr', 'ip_address', 'cl_ip_address', 'client', 'connection_id',
               'database', ' tbl', 'message'),
    'DTL.STAT': ('dtl_time', 'dtl_type', 'dtl_server_ip', 'usr', 'dtl_client_ip',
                 'dtl_file_id', 'dtl_file_name', 'dtl_execute_time', 'dtl_execute_num',
                 'dtl_status', 'dtl_execute_type'),
    'ERROR': ('type', 'error_code', 'lh', 'usr', 'ip_address', 'cl_ip_address',
              'client', 'connection_id', 'database', 'message'),
    'IMPORT': ('lh', 'usr', 'ip_address', 'cl_ip_address', 'client', 'error_code',
               'database', ' tbl', 'message'),
    'IMPORT-TASK': ('message'),
    'MONITOR.DRSUMEA': ('index_class', 'index_name', 'index_type', 'value', 'detail', 'index_id', 'comment'),
    'MONITOR.SYSTEM': ('index_class', 'index_name', 'index_type', 'value', 'detail', 'index_id', 'comment'),
    'OLAP': ('lh', 'usr', 'ip_address', 'cl_ip_address', 'client', 'database', ' tbl',
             'row', 'col', 'agg', 'rtx', 'rtx_drill', 'target_num', 'total_num',
             'row_num', 'col_num', 'execute_time'),
    'OPERATION': ('lh', 'usr', 'ip_address', 'cl_ip_address', 'client', 'operation', 'parameter'),
    'SQL': ('type', 'lh', 'usr', 'ip_address', 'cl_ip_address', 'client',
            'connection_id', 'database', 'sql'),
    'STATE': ('error_code', 'type', 'message'),
    'COMMON': ('log_name', 'cl_timestamp', 'cl_date', 'cl_time', 'year', 'month', 'day', 'hour', 'minute',
               'sequence_num', 'host_id', 'request_id')
}
