# -*- coding: utf-8 -*-
from .. import dw_exception as ex
import csv
__author__ = 'ishii.y'


def create(con, condition):
    return Downloader(con, condition)


class Downloader:
    """
    ログダウンローダ
    """
    def __init__(self, con, condition):
        self.con = con
        self.log_handle = 0
        self.block_count = 1000  # 一度に読み込む行数
        self.condition = None
        self.__open(condition)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __open(self, condition):
        self.close()
        proc_h = 0
        py_str = ""
        py_str += "handle=DWPyFile.LogDownloadOpen(login_handle,%d,%s)\n" % (proc_h, condition.py_run_str())
        py_str += "if DWPyFile.error >= 0 and handle != 0:\n"
        py_str += "  s_log_handle=str(handle)\n"
        self.con.run_string(py_str)
        ret, msg = self.con.get_error_code('DWPyFile')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        handle_str = self.con.get_value_string("s_log_handle")
        self.log_handle = int(handle_str)
        self.condition = condition

    def load(self, n=None):
        """
        ログ取得
        log_countが0になったら、取得終了。
        :param n:
        :return:{data:ログデータ, log_count=ログ件数, max_seq_num=最大シーケンス番号,
        log_remain=指定した最大件数以上にデータが存在する場合に非0
        """
        if self.log_handle == 0:
            return dict(data=[[]], log_count=0, max_seq_num=0, log_remain=0)
        if n is None:
            n = self.block_count

        py_str = ""
        py_str += "res=DWPyFile.LogDownloadGetData(login_handle,%d,%d)\n" % (self.log_handle, n)
        self.con.run_string(py_str)
        ret, msg = self.con.get_error_code('DWPyFile')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        py_str = ""
        py_str += "data=res[0]\n"
        py_str += "log_count=res[1]\n"
        py_str += "max_seq_num=res[2]\n"
        py_str += "log_remain=res[3]\n"
        self.con.run_string(py_str)
        log_data = self.con.get_value_string("data")  # ログデータ
        log_count = self.con.get_value_int("log_count")  # 取得したログ件数
        max_seq_num = self.con.get_value_int("max_seq_num") # 最大シーケンス番号
        log_remain = self.con.get_value_int("log_remain")  # 残りのデータの有無

        return dict(data=self.get_records(log_data), log_count=log_count, max_seq_num=max_seq_num, log_remain=log_remain)

    def close(self):
        if self.log_handle == 0:
            return
        py_str = "DWPyFile.LogDownloadClose(login_handle, %d)\n" % self.log_handle
        self.con.run_string(py_str)
        ret, msg = self.con.get_error_code('DWPyFile')
        if ret >= 0x80000000:
            raise ex.create_with_msg(ret, msg)
        self.log_handle = 0

    def load_all(self):
        """
        全データを一括で取得
        :return:
        """
        loaded_count = 0
        max_seq_num = 0
        log_remain = 0
        data = []
        while True:
            res = self.load(self.block_count)
            if res['log_count'] == 0:
                log_remain = res['log_remain']
                break
            loaded_count += res['log_count']
            max_seq_num = res['max_seq_num']
            data += res['data']

        return dict(loaded_count=loaded_count, max_seq_num=max_seq_num, log_remain=log_remain, data=data)

    def write_csv(self, file_name, mode='w', header=False):
        """
        csvへ出力
        :param file_name:出力ファイル名
        :param mode:'w':新規, 'a':追記
        :param header: ヘッダーの有無
        :return:
        """
        loaded_count = 0
        max_seq_num = 0
        log_remain = 0
        with open(file_name, mode, newline='', encoding='utf-8') as f:
            wr = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
            if header:
                wr.writerow(self.condition.csv_header())
            while True:
                res = self.load(self.block_count)
                if res['log_count'] == 0:
                    log_remain = res['log_remain']
                    break
                loaded_count += res['log_count']
                max_seq_num = res['max_seq_num']
                wr.writerows(res['data'])

        return dict(loaded_count=loaded_count, max_seq_num=max_seq_num, log_remain=log_remain)

    def column_ids(self):
        return self.condition.column_ids()

    @classmethod
    def get_records(cls, rec_str):
        """
        取得したレコードセット文字列からレコードセットを生成する。
        ２次元のリスト形式
        :param rec_str:
        :return:
        """
        row_dlm = '\x02'
        col_dlm = '\x01'
        ret = []
        for row in rec_str.split(row_dlm):
            cols = row.split(col_dlm)
            ret.append(cols)
        ret.pop()  # 最終行を削除
        return ret
