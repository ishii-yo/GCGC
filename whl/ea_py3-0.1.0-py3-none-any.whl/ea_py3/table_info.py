# -*- coding: utf-8 -*-
from enum import IntEnum
__author__ = 'ishii.y'


def create(tab):
    t = TableInfo()
    t.type = tab['type']
    t.name = tab['name']
    t.comment = tab['comment']
    t.columns = tab['column'].split(',')
    t.broken = (tab['broken'] == 1)
    t.partition = tab['partition']
    t.in_memory_status = tab['inmemory']
    t.select = tab['select']
    t.connect = tab['connect']
    t.last_modified_date = tab['modify_date']
    t.last_modified_user = tab['modify_user']
    t.last_defined_date = tab['define_date']
    t.last_defined_user = tab['define_user']
    if t.type == TableType.LINK:
        t.link_database, t.link_table = tab['connect'].split('.')
    return t


class TableInfo:
    def __init__(self):
        self.type = TableType.TABLE
        self.name = ''
        self.comment = ''
        self.columns = []
        self.select = ''
        self.connect = ''
        self.last_modified_date = ''
        self.last_modified_user = ''
        self.last_defined_date = ''
        self.last_defined_user = ''
        self.link_database = ''
        self.link_table = ''
        self.broken = False
        self.partition = 0
        self.in_memory_status = InmeoryStatus.NOT_IN_MEMORY

    def __str__(self):
        return 'name=%s,type=%d,comment=%s,columns=%s,select=%s,connect=%s,last_modified_date=%s,' \
               'last_modified_user=%s,last_defined_date=%s,last_defined_user=%s,' \
               'link_database=%s,link_table=%s,broken=%s,' \
               'partition=%d,in_memory_status=%d' % (self.name, self.type, self.comment, self.columns,self.select,
                                                     self.connect, self.last_modified_date, self.last_modified_user,
                                                     self.last_defined_date, self.last_defined_user,
                                                     self.link_database,self.link_table, self.broken, self.partition,
                                                     self.in_memory_status)


class TableType(IntEnum):
    TABLE = 0
    VIEW = 1
    MVIEW = 2
    LINK = 3
    DISTRIBUTOR =3


class InmeoryStatus(IntEnum):
    NOT_IN_MEMORY = 0
    IN_MEMORY_UNLOAD = 1
    IN_MEMORY_ONLOAD = 2
    IN_MEMORY_LOADED = 3
